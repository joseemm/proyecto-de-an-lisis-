# Importar las librerías necesarias
import pandas as pd
import requests
from bs4 import BeautifulSoup

# Definir las URLs de las páginas web
url1 = "https://es.wikipedia.org/wiki/Servicio_de_red_social"
url2 = "https://escala.com/blog/redes-sociales-mas-usadas-latam"

# Obtener el código HTML de la primera página web
response1 = requests.get(url1)
html1 = response1.text

# Crear un objeto BeautifulSoup con el HTML de la primera página web
soup1 = BeautifulSoup(html1, "html.parser")

# Buscar la tabla que contiene la lista de redes sociales
table1 = soup1.find("table", class_="wikitable")

# Leer la tabla con pandas y obtener un DataFrame
df1 = pd.read_html(str(table1))[0]


df1 = df1[["Servicio", "Usuarios activos (en millones)"]]

# Ordenar el DataFrame por el número de usuarios activos de mayor a menor
df1 = df1.sort_values(by="Usuarios activos (en millones)", ascending=False)



# Mostrar el DataFrame resultante
print(df1)


response3 = requests.get(url1)
html3 = response3.text

# Crear un objeto BeautifulSoup con el HTML de la tercera página web
soup3 = BeautifulSoup(html3, "html.parser")

# Buscar la tabla que contiene la tasa de penetración de redes sociales en América Latina y Caribe por país en enero de 2021
table3 = soup3.find_all("table", class_="wikitable")[0] # Es la quinta tabla con esta clase

# Leer la tabla con pandas y obtener un DataFrame
df3 = pd.read_html(str(table3))[0]





# Mostrar el DataFrame resultante
print(df3)


# Obtener el código HTML de la segunda página web
response2 = requests.get(url2)
html2 = response2.text

# Crear un objeto BeautifulSoup con el HTML de la segunda página web
soup2 = BeautifulSoup(html2, "html.parser")

# Buscar la tabla que contiene el ranking de redes sociales en Latinoamérica
table2 = soup2.find("table")

# Leer la tabla con pandas y obtener un DataFrame
df2 = pd.read_html(str(table2))[0]



# Mostrar el DataFrame resultante
print(df2)


# Almacenar la data de df1 en una lista
lista1 = df1.values.tolist()

# Almacenar la data de df2 en una lista
lista2 = df2.values.tolist()

# Almacenar la data de df3 en una lista
lista3 = df3.values.tolist()


