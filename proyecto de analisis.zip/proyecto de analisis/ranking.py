
# Importar las librerías necesarias
import pandas as pd
import requests
from bs4 import BeautifulSoup

# Definir las URLs de las páginas web
url1 = "https://es.wikipedia.org/wiki/Servicio_de_red_social"
url2 = "https://escala.com/blog/redes-sociales-mas-usadas-latam"
# Obtener el código HTML de la segunda página web
response2 = requests.get(url2)
html2 = response2.text

# Crear un objeto BeautifulSoup con el HTML de la segunda página web
soup2 = BeautifulSoup(html2, "html.parser")

# Buscar la tabla que contiene el ranking de redes sociales en Latinoamérica
table2 = soup2.find("table")

# Leer la tabla con pandas y obtener un DataFrame
df2 = pd.read_html(str(table2))[0]


# Crear el dataframe con los datos
df2 = pd.DataFrame([["Argentina", "47%", "45%", "5,9%", "2,1%"],
                               ["Brasil", "54%", "37%", "6%", "3%"],
                               ["Chile", "47%", "45%", "4,5%", "1,5%"],
                               ["Colombia", "47%", "42%", "7,5%", "35%"],
                               ["México", "51%", "37%", "7%", "5%"],
                               ["Perú", "47%", "21,5%", "3%", "3,5%"]],
                              columns=["País", "Facebook", "Instagram", "Twitter", "YouTube"])

# Reemplazar la coma por el punto en las columnas numéricas
df2["Facebook"] = df2["Facebook"].str.replace(",", ".")
df2["Instagram"] = df2["Instagram"].str.replace(",", ".")
df2["Twitter"] = df2["Twitter"].str.replace(",", ".")
df2["YouTube"] = df2["YouTube"].str.replace(",", ".")


# Mostrar el DataFrame resultante
print(df2)


# Almacenar la data de df2 en una lista
lista2 = df2.values.tolist()

# Exportar df2 a un archivo CSV llamado "ranking_latam.csv"
df2.to_csv("ranking_latam.csv", index=False)